# non อัพเดตแล้ว

NON BOT LINE



Bot flex non bot line 


Botflex by. Non

สคลิปคนเหี้ย แจกฟรีไม่คิดตังค์

apt-get install nodejs -y

apt-get install npm -y

pip3 install thrift==0.11.0

pip3 install rsa

pip3 install requests

pip3 install bs4

pip3 install gtts

pip3 install googletrans

pip3 install html5

pip3 install wikipedia

pip3 install pytz

pip3 install humanfriendly

pip3 install pafy

pip3 install youtube_dl

pip3 install keepalive

pip3 install linepy

pip3 install linepy==2.0.2

pip3 install datatime

pip3 install unzip

pip3 install pip --upgrade

cp -v /usr/local/bin/pip3 /usr/bin/pip3

pip3 install setuptools

pip3 install tweepy

pip3 install linepy

pip3 install html5lib

pip3 install pafy

pip3 install youtube_dl

pip3 install humanfriendly

pip3 install gtts

pip3 install googletrans

pip3 install pytz

pip3 install wikipedia

cd non

python3 mmx.py

Bot flex by. non bot line

 (free) scip 

คนเหี้ยแจกฟรีไม่คิดเงิน
